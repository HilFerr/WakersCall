import color
from models import *
from functions import *


def cover():
    print("""
          
    ░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░▒▓███████▓▒░ ░▒▓███████▓▒░       ░▒▓██████▓▒░ ░▒▓██████▓▒░░▒▓█▓▒░      ░▒▓█▓▒░        
    ░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░             ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        
    ░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░             ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        
    ░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░▒▓███████▓▒░░▒▓██████▓▒░ ░▒▓███████▓▒░ ░▒▓██████▓▒░       ░▒▓█▓▒░      ░▒▓████████▓▒░▒▓█▓▒░      ░▒▓█▓▒░        
    ░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        
    ░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░        
     ░▒▓█████████████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓███████▓▒░        ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░▒▓████████▓▒░ 
    
    """)
    input("Press [ENTER] to start...")


def main():
    cover()

    ship1 = Model("Explorer", color.BLUE + color.BOLD + color.NO_ITALIC, 30, "E")
    ship2 = Model("Defender", color.GREEN + color.BOLD + color.NO_ITALIC, 25, "D")
    ship3 = Model("Attacker", color.RED + color.BOLD + color.NO_ITALIC, 20, "A")
    ships = [ship1, ship2, ship3]

    board_size = 5
    total_shots = 0
    hits = 0


    while True:
        cls()

        ships_board = drawBoard(board_size)
        shots_board = drawBoard(board_size)

        ships_positions = printShips(ships_board, ships)
        shots = printShots(shots_board, 3, board_size)

        print(color.WHITE + color.BOLD + color.NO_ITALIC + "\nSHIP'S BOARD:")
        printBoard(ships_board, ships)

        print(color.WHITE + color.BOLD + color.NO_ITALIC + "\nGAME BOARD:")
        printBoard(shots_board, ships)

        print(color.WHITE + color.BOLD + color.NO_ITALIC + "\nSTATS:")
        for ship in ships:
            ship.stats()

        print(color.YELLOW + color.BOLD + color.NO_ITALIC + "\nTotal Shots:", color.WHITE + color.NO_BOLD + color.ITALIC, total_shots)
        print(color.YELLOW + color.BOLD + color.NO_ITALIC + "Hits:", color.WHITE + color.NO_BOLD + color.ITALIC, hits)
        print(color.YELLOW + color.BOLD + color.NO_ITALIC + "Accuracy:", color.WHITE + color.NO_BOLD + color.ITALIC, efficiency(total_shots, hits), "%")


        for shot in shots:
            if shot in ships_positions:
                hits += 1
                for ship in ships:
                    if ships_board[shot[0]][shot[1]] == ship.letter:
                        ship.energyLoss(10)
                        if ship.energy == 0:
                            ships_board[shot[0]][shot[1]] = "."
                            cls()
                            print(color.RED + color.BOLD + color.NO_ITALIC + f"\n{ship.name} has been destroyed!")

        total_shots += 3


        if all(ship.energy == 0 for ship in ships) or total_shots >= 105:
            cls()
            print(color.RED + color.BOLD + color.NO_ITALIC + ("\n=== GAME OVER ===\n"))

            for ship in ships:
                ship.stats()

            print(color.YELLOW + color.NO_BOLD + color.NO_ITALIC + "\nTotal Shots:", 
                  color.WHITE + color.NO_BOLD + color.ITALIC, total_shots, 
                  color.YELLOW + color.NO_BOLD + color.NO_ITALIC + " Accurate Shots:",
                  color.WHITE + color.NO_BOLD + color.ITALIC, hits)
            print(color.YELLOW + color.NO_BOLD + color.NO_ITALIC + "Final Accuracy:", color.WHITE + color.NO_BOLD + color.ITALIC, efficiency(total_shots, hits), "% \n")
            break

        input(color.RED + color.NO_BOLD + color.ITALIC + ("\nPress [ENTER] for the next round..."))


if __name__ == "__main__":
    main()
