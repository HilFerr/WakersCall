RED       = '\033[31m'
GREEN     = '\033[32m'
YELLOW    = '\033[33m'
BLUE      = '\033[34m'
WHITE     = '\033[37m'

ITALIC    = '\033[3m'
NO_ITALIC = '\033[23m'

BOLD      = '\033[1;1m'
NO_BOLD   = '\033[22m'